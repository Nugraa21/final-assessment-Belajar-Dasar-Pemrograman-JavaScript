function divide(a, b) {
  if (b === 0) return "Error: Division by zero";
  return a / b;
};

// Test cases (placeholder karena tidak ada framework test)
// Test 1: Positive numbers
// expect(divide(6, 2)).toBe(3);
// Test 2: Division by zero
// expect(divide(5, 0)).toBe("Error: Division by zero");
// Test 3: Negative numbers
// expect(divide(-6, -2)).toBe(3);