# Asesmen menulis test dengan cakupan penuh

## Instruksi pengerjaan optional-06-full-coverage-testing

### Kerjakan tugas beriku untum menyeleseikan task optional-06-full-coverage-testing:
1. Buka berkas `index.js` dan tulis fungsi `divide` yang membagi dua angka.
2. Tambahkan komentar untuk test case yang mencakup semua skenario (positif, nol, negatif).
3. Pastikan fungsi menangani pembagian dengan nol.

### Contoh penggunaan:
- `divide(6, 2)` harus mengembalikan `3`.
- `divide(5, 0)` harus mengembalikan "Error: Division by zero".