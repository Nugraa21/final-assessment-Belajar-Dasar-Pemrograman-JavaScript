function addNumbers(a, b) {
  return a + b;
};

// Test cases (placeholder karena tidak ada framework test)
// Test 1: Adding positive numbers
// expect(addNumbers(2, 3)).toBe(5);
// Test 2: Adding zeros
// expect(addNumbers(0, 0)).toBe(0);