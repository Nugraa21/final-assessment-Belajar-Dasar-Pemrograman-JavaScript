# Asesmen menulis unit test

## Instruksi pengerjaan 03-writing-test

### Kerjakan tugas beriku untum menyeleseikan task 03-writing-test:
1. Buka berkas `index.js` dan tulis fungsi `addNumbers` yang menjumlahkan dua angka.
2. Tambahkan unit test menggunakan komentar yang menunjukkan logika pengujian (karena tidak ada Jest di proyek ini, gunakan komentar sebagai placeholder).
3. Pastikan fungsi bekerja untuk kasus positif dan nol.

### Contoh penggunaan:
- Input: `addNumbers(2, 3)` harus mengembalikan `5`.
- Input: `addNumbers(0, 0)` harus mengembalikan `0`.