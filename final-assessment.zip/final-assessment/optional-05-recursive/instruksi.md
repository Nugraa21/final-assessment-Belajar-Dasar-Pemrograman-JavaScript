# Asesmen menerapkan rekursi

## Instruksi pengerjaan optional-05-recursive

### Kerjakan tugas beriku untum menyeleseikan task optional-05-recursive:
1. Buka berkas `index.js` dan tulis fungsi rekursif `factorial` yang menghitung faktorial suatu angka.
2. Pastikan fungsi mengembalikan nilai yang benar untuk input 0, 1, dan angka positif.
3. Tambahkan penanganan error untuk input negatif.

### Contoh penggunaan:
- `factorial(5)` harus mengembalikan `120` (5 × 4 × 3 × 2 × 1).
- `factorial(0)` harus mengembalikan `1`.