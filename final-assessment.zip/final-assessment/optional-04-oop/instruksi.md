# Asesmen menerapkan OOP

## Instruksi pengerjaan optional-04-oop

### Kerjakan tugas beriku untum menyeleseikan task optional-04-oop:
1. Buka berkas `index.js` dan buat kelas `Animal` dengan properti `name` dan metode `speak`.
2. Buat kelas turunan `Dog` yang mewarisi `Animal` dan menimpa metode `speak` untuk mengembalikan "Woof!".
3. Pastikan kedua kelas dapat diinstansiasi.

### Contoh penggunaan:
- `new Dog("Rex").speak()` harus mengembalikan "Woof!".