# Asesmen menulis komentar di JavaScript

## Instruksi pengerjaan 01-writing-comments

### Kerjakan tugas beriku untum menyeleseikan task 01-writing-comments:
1. Buka berkas `index.js` dan tuliskan "username" akun Dicoding Anda dalam bentuk komentar satu baris.
2. Buka berkas `index.js` dan tuliskan teks di bawah ini dalam bentuk komentar banyak baris:
   - Goal tahunan:
     1. Belajar JavaScript.
     2. Menjadi Front-End atau Back-End Developer.

### Cara mengetahu username Dicoding
1. Buka halaman pengaturan akun Dicoding dengan klik url https://www.dicoding.com/settings/profile.
2. Jika belum login, silakan login dengan akun Dicoding Anda.
3. Anda bisa melihat nama login Anda di kolom Username.