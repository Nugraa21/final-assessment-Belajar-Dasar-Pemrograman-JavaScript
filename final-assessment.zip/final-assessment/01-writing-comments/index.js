// nugra21_ev3h

/*
 *Goal tahun ini:
 *1. Belajar JavaScript.
 *2. Menjadi Front-End atau Back-End Developer.
 */
