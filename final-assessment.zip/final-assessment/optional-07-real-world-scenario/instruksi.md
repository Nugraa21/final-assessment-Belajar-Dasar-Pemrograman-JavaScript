# Asesmen menerapkan skenario dunia nyata

## Instruksi pengerjaan optional-07-real-world-scenario

### Kerjakan tugas beriku untum menyeleseikan task optional-07-real-world-scenario:
1. Buka berkas `index.js` dan buat objek `calculator` dengan metode `add` dan `subtract`.
2. Pastikan metode bekerja untuk angka positif dan negatif.
3. Tambahkan komentar untuk mendokumentasikan penggunaan.

### Contoh penggunaan:
- `calculator.add(5, 3)` harus mengembalikan `8`.
- `calculator.subtract(5, 3)` harus mengembalikan `2`.