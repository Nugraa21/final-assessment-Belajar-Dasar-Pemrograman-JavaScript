function calculateArea(length, width) {
  return length * width;
};